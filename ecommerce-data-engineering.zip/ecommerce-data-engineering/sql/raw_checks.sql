-- Phase 2: verify raw storage (no cleaning)
SELECT COUNT(*) AS raw_rows FROM raw.ecommerce_orders;
SELECT source_file, row_number, record FROM raw.ecommerce_orders ORDER BY row_number LIMIT 5;
SELECT run_id, started_at, finished_at, rows_fetched, status, error_message
FROM raw.ingestion_runs ORDER BY run_id DESC LIMIT 10;
