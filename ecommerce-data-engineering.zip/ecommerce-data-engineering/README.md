# E-Commerce Sales Data Engineering Project

Phase 1 (proposal and environment) + Phase 2 (containerized raw ingestion).

## Dataset
Approved E-Commerce Sales CSV: `data/ecommerce_sales_34500.csv` — 34,500 rows, 17 columns.
The CSV is bundled in this ZIP for local demonstration but intentionally ignored by Git.

## Analytical questions (from Phase 1)
1. Which product categories generate the highest total sales revenue?
2. How do monthly sales revenues change over time?
3. Which product categories have the highest return rates?

## Architecture
CSV → Python ingestion → PostgreSQL raw schema → (future: Kestra orchestration / dashboard).
Phase 2 does not run Kestra or clean data.

## Quick start in Ubuntu / WSL
Prerequisites: Docker + Docker Compose, engine running.

```bash
cd ecommerce-data-engineering
cp .env.example .env
# Edit .env and replace placeholder passwords (do not commit it)
docker compose config --quiet
docker compose up -d pgdatabase pgadmin
docker compose build ingestion
docker compose run --rm ingestion
docker compose ps
```

Open pgAdmin at http://localhost:8080; register server with **Host: pgdatabase**,
**Port: 5432**, **Database/User/Password** from `.env`.

```sql
SELECT COUNT(*) FROM raw.ecommerce_orders; -- Expected 34500 after ingestion
SELECT * FROM raw.ecommerce_orders ORDER BY row_number LIMIT 5;
SELECT * FROM raw.ingestion_runs ORDER BY run_id DESC LIMIT 5;
```

Raw file preservation:
```bash
sha256sum data/ecommerce_sales_34500.csv data/raw/ecommerce_sales_34500.csv
python3 scripts/profile_data.py
```
Both SHA-256 values must match. Profiling writes `docs/phase2_profile.md`.
It does not edit any rows. Ingestion is safe to rerun without multiplying records.

## Deliverables
- `scripts/ingest_data.py`: reusable source-to-raw pipeline, error handling and logs
- `Dockerfile` + `requirements.txt` + `docker-compose.yml`
- `data/raw/`: byte-identical landing copy (created at runtime)
- `raw.ecommerce_orders`: raw JSONB records, `raw.ingestion_runs`: run history
- `scripts/profile_data.py`, `docs/phase2_profile.md`: raw profiling
- `docs/phase2_notes.md`, `sql/raw_checks.sql`: lab notes and SQL verification
- `docs/Phase1_Proposal.pdf`, architecture diagram: retained from Phase 1

## Safety / sharing
`.env`, local raw data, and `.git` metadata are omitted from this distribution ZIP.
Never commit passwords or access tokens. The included dataset is for local setup;
it remains excluded from normal Git commits by `.gitignore`.

## Shut down safely
`docker compose down` stops containers without removing the persistent database volume.
Do **not** run `docker compose down -v` unless you want to delete database contents.
