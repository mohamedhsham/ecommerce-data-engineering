# Phase 2 — Data Ingestion, Raw Storage & Containerization

## Dataset and source
E-Commerce Sales CSV (`data/ecommerce_sales_34500.csv`), 34,500 rows and 17 columns.
The approved local CSV supplied with Phase 1 is the source for this offline demonstration.
It is not automatically downloaded from an external URL. The original public dataset URL
should be documented separately if required by the instructor.

## Ingestion and failure handling
Run `docker compose run --rm ingestion`. The modular Python script verifies the CSV exists,
copies it byte-for-byte to `data/raw/`, checks both copies using SHA-256, and reads CSV records
in batches of 1,000 using `csv.DictReader`. It connects to PostgreSQL using Compose service name
`pgdatabase` and environment variables. Missing files, malformed CSV headers or rows, connection
failures, and database errors are logged. Failed ingestion transactions are rolled back.

## Raw storage
- File landing zone: `data/raw/ecommerce_sales_34500.csv` (exact file copy).
- Database: `raw.ecommerce_orders` with `source_file`, `row_number`, `record JSONB`, and `ingested_at`.
- CSV values in JSONB are kept as their original strings; no cleaning or type conversions are applied.
- `(source_file, row_number)` is a key, so rerunning ingestion updates instead of duplicating rows.
- `raw.ingestion_runs` stores run timestamps, source SHA-256, fetched count, status, and errors.

## Docker and networking
PostgreSQL and pgAdmin are retained from Phase 1. The new ingestion image is built from
`Dockerfile`; all services share the Compose default network. PostgreSQL uses a named volume;
the input CSV uses a read-only bind mount; raw file landing uses a local bind mount.

## Data-quality profiling
Run `python3 scripts/profile_data.py` (standard library only). Results are generated in
`docs/phase2_profile.md`. Check missing/empty fields, exact duplicate rows, invalid
dates, nonnumeric values, and negative values. These are potential issues only.
No corrections or deletions belong in Phase 2; transformations come in Phase 3.

## Lab verification
Run the ingestion container and show logs, check `raw.ecommerce_orders` in pgAdmin,
compare `sha256sum` of source and landing files, and execute `sql/raw_checks.sql`.
Each team member should explain Dockerfile instructions, service DNS, volumes, logging,
retry/rerun behavior and preservation of raw data.
