# Phase 2 — Raw Data Profiling Results

- Source: `data/raw/ecommerce_sales_34500.csv`
- Rows: 34,500
- Columns: 17
- Exact duplicate rows: 0
- Nonempty invalid dates (YYYY-MM-DD): 0

## Columns and missing values

| Column | Missing / empty |
|---|---:|
| order_id | 0 |
| customer_id | 0 |
| product_id | 0 |
| category | 0 |
| price | 0 |
| discount | 0 |
| quantity | 0 |
| payment_method | 0 |
| order_date | 0 |
| delivery_time_days | 0 |
| region | 0 |
| returned | 0 |
| total_amount | 0 |
| shipping_cost | 0 |
| profit_margin | 0 |
| customer_age | 0 |
| customer_gender | 0 |

## Numeric checks

| Column | Invalid numeric | Negative values |
|---|---:|---:|
| price | 0 | 0 |
| discount | 0 | 0 |
| quantity | 0 | 0 |
| total_amount | 0 | 0 |
| shipping_cost | 0 | 0 |
| profit_margin | 0 | 6,104 |
| customer_age | 0 | 0 |
| delivery_time_days | 0 | 0 |

These are observations only; no rows have been cleaned or removed.
Some negative values (for example profit margin) may be valid; confirm business rules in Phase 3.
