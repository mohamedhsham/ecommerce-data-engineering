"""Profile source CSV without changing any record. Writes Markdown report."""
import csv
import os
from collections import Counter
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

SOURCE = Path(os.getenv("PROFILE_CSV", "data/raw/ecommerce_sales_34500.csv"))
OUTPUT = Path(os.getenv("PROFILE_REPORT", "docs/phase2_profile.md"))
NUMERIC_COLUMNS = ("price", "discount", "quantity", "total_amount", "shipping_cost", "profit_margin", "customer_age", "delivery_time_days")

def profile():
    if not SOURCE.exists():
        raise FileNotFoundError(f"Run ingestion first: {SOURCE}")
    missing = Counter()
    negative = Counter()
    numeric_invalid = Counter()
    invalid_dates = 0
    seen = set()
    duplicates = 0
    rows = 0
    with SOURCE.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        columns = reader.fieldnames or []
        for row in reader:
            rows += 1
            key = tuple(row.get(column) for column in columns)
            if key in seen:
                duplicates += 1
            seen.add(key)
            for column in columns:
                if row.get(column) is None or not str(row[column]).strip():
                    missing[column] += 1
            for column in NUMERIC_COLUMNS:
                if column not in columns or not str(row.get(column) or "").strip():
                    continue
                try:
                    if Decimal(row[column]) < 0:
                        negative[column] += 1
                except InvalidOperation:
                    numeric_invalid[column] += 1
            date = (row.get("order_date") or "").strip()
            if date:
                try:
                    datetime.strptime(date, "%Y-%m-%d")
                except ValueError:
                    invalid_dates += 1
    lines = ["# Phase 2 — Raw Data Profiling Results", "", f"- Source: `{SOURCE}`", f"- Rows: {rows:,}", f"- Columns: {len(columns)}", f"- Exact duplicate rows: {duplicates:,}", f"- Nonempty invalid dates (YYYY-MM-DD): {invalid_dates:,}", "", "## Columns and missing values", "", "| Column | Missing / empty |", "|---|---:|"]
    for column in columns:
        lines.append(f"| {column} | {missing[column]:,} |")
    lines += ["", "## Numeric checks", "", "| Column | Invalid numeric | Negative values |", "|---|---:|---:|"]
    for column in NUMERIC_COLUMNS:
        if column in columns:
            lines.append(f"| {column} | {numeric_invalid[column]:,} | {negative[column]:,} |")
    lines += ["", "These are observations only; no rows have been cleaned or removed.", "Some negative values (for example profit margin) may be valid; confirm business rules in Phase 3.", ""]
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    print(f"Saved report: {OUTPUT}")

if __name__ == "__main__":
    profile()
