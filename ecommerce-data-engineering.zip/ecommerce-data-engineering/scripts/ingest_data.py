"""Phase 2: preserve original CSV and ingest as unmodified field strings."""
import csv
import hashlib
import logging
import os
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import psycopg2
from psycopg2.extras import Json, execute_values

LOG = logging.getLogger("ecommerce.ingestion")
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
SOURCE = Path(os.getenv("SOURCE_CSV", "/app/data/ecommerce_sales_34500.csv"))
RAW_DIR = Path(os.getenv("RAW_DIR", "/app/data/raw"))
BATCH_SIZE = 1000

def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def preserve_source():
    """Copy source byte-for-byte into landing zone, verify SHA-256."""
    if not SOURCE.is_file():
        raise FileNotFoundError(f"Source CSV not found: {SOURCE}")
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    destination = RAW_DIR / SOURCE.name
    if SOURCE.resolve() != destination.resolve():
        tmp = destination.with_suffix(destination.suffix + ".tmp")
        shutil.copyfile(SOURCE, tmp)
        os.replace(tmp, destination)
    original_hash = sha256(SOURCE)
    if original_hash != sha256(destination):
        raise RuntimeError("Raw landing copy SHA-256 mismatch")
    LOG.info("Raw landing file: %s", destination)
    LOG.info("Source SHA-256: %s", original_hash)
    return destination, original_hash

def database_connection():
    return psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "pgdatabase"),
        port=int(os.getenv("POSTGRES_PORT", "5432")),
        dbname=os.environ["POSTGRES_DB"],
        user=os.environ["POSTGRES_USER"],
        password=os.environ["POSTGRES_PASSWORD"],
        connect_timeout=10,
    )

def setup_tables(connection):
    with connection.cursor() as cursor:
        cursor.execute("""
            CREATE SCHEMA IF NOT EXISTS raw;
            CREATE TABLE IF NOT EXISTS raw.ecommerce_orders (
                source_file TEXT NOT NULL,
                row_number INTEGER NOT NULL,
                record JSONB NOT NULL,
                ingested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                PRIMARY KEY (source_file, row_number)
            );
            CREATE TABLE IF NOT EXISTS raw.ingestion_runs (
                run_id BIGSERIAL PRIMARY KEY,
                started_at TIMESTAMPTZ NOT NULL,
                finished_at TIMESTAMPTZ NOT NULL,
                source_file TEXT NOT NULL,
                source_sha256 CHAR(64),
                rows_fetched INTEGER NOT NULL,
                status TEXT NOT NULL,
                error_message TEXT
            );
        """)

def insert_batch(cursor, batch):
    execute_values(cursor, """
        INSERT INTO raw.ecommerce_orders (source_file, row_number, record)
        VALUES %s
        ON CONFLICT (source_file, row_number)
        DO UPDATE SET record = EXCLUDED.record, ingested_at = NOW()
    """, batch, page_size=BATCH_SIZE)

def load_csv(connection, raw_file):
    count = 0
    with raw_file.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError("Missing or duplicated CSV column headers")
        with connection.cursor() as cursor:
            batch = []
            for row_number, record in enumerate(reader, start=1):
                if None in record:
                    raise ValueError(f"Unexpected extra fields on CSV record {row_number}")
                batch.append((SOURCE.name, row_number, Json(record)))
                if len(batch) >= BATCH_SIZE:
                    insert_batch(cursor, batch)
                    count += len(batch)
                    batch.clear()
            if batch:
                insert_batch(cursor, batch)
                count += len(batch)
    return count

def record_run(connection, started, source_hash, rows, status, error):
    with connection.cursor() as cursor:
        cursor.execute("""
            INSERT INTO raw.ingestion_runs
            (started_at, finished_at, source_file, source_sha256,
             rows_fetched, status, error_message)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (started, datetime.now(timezone.utc), SOURCE.name,
              source_hash, rows, status, error))

def main():
    start = datetime.now(timezone.utc)
    start_clock = time.monotonic()
    rows = 0
    checksum = None
    LOG.info("Ingestion started at %s", start.isoformat())
    try:
        raw_file, checksum = preserve_source()
        with database_connection() as connection:
            setup_tables(connection)
            rows = load_csv(connection, raw_file)
            record_run(connection, start, checksum, rows, "SUCCESS", None)
        LOG.info("Records fetched: %d", rows)
        LOG.info("Execution status: SUCCESS")
    except Exception as error:
        LOG.exception("Execution status: FAILED")
        # Record failed attempts if PostgreSQL is reachable. Ingestion
        # inserts are rolled back on failure; failure log uses fresh transaction.
        try:
            with database_connection() as connection:
                setup_tables(connection)
                record_run(connection, start, checksum, rows, "FAILED", str(error)[:2000])
        except Exception:
            LOG.warning("Could not persist failed run to PostgreSQL")
        return 1
    finally:
        LOG.info("Execution duration: %.2fs", time.monotonic() - start_clock)
    return 0

if __name__ == "__main__":
    sys.exit(main())
